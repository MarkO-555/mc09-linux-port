/*
 * Determine if a character is alphabetic
 *
 * ?COPY.TXT 1988-2005 Dave Dunfield
 *  -- see COPY.TXT --.
 */
isalpha(c)
	unsigned c;
{
	return islower(c) || isupper(c);
}
