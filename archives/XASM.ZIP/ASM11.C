/*
 * 68HC11 Cross Assembler
 *
 * ?COPY.TXT 1983-2005 Dave Dunfield
 * **See COPY.TXT**.
 */
#include <stdio.h>
#include <ctype.h>

#include "xasm.h"

/* 6811 opcode table */
static char opcodes[] = {
	'A','B','A',		0x81, 0x1B, 0x00,
	'C','L','R','A',	0x81, 0x4f, 0x00,
	'C','L','R','B',	0x81, 0x5f, 0x00,
	'C','B','A',		0x81, 0x11, 0x00,
	'C','O','M','A',	0x81, 0x43, 0x00,
	'C','O','M','B',	0x81, 0x53, 0x00,
	'N','E','G','A',	0x81, 0x40, 0x00,
	'N','E','G','B',	0x81, 0x50, 0x00,
	'D','A','A',		0x81, 0x19, 0x00,
	'D','E','C','A',	0x81, 0x4a, 0x00,
	'D','E','C','B',	0x81, 0x5a, 0x00,
	'I','N','C','A',	0x81, 0x4c, 0x00,
	'I','N','C','B',	0x81, 0x5c, 0x00,
	'P','S','H','A',	0x81, 0x36, 0x00,
	'P','S','H','B',	0x81, 0x37, 0x00,
	'P','U','L','A',	0x81, 0x32, 0x00,
	'P','U','L','B',	0x81, 0x33, 0x00,
	'R','O','L','A',	0x81, 0x49, 0x00,
	'R','O','L','B',	0x81, 0x59, 0x00,
	'R','O','R','A',	0x81, 0x46, 0x00,
	'R','O','R','B',	0x81, 0x56, 0x00,
	'A','S','L','A',	0x81, 0x48, 0x00,
	'A','S','L','B',	0x81, 0x58, 0x00,
	'A','S','R','A',	0x81, 0x47, 0x00,
	'A','S','R','B',	0x81, 0x57, 0x00,
	'L','S','R','A',	0x81, 0x44, 0x00,
	'L','S','R','B',	0x81, 0x54, 0x00,
	'L','S','L','A',	0x81, 0x48, 0x00,
	'L','S','L','B',	0x81, 0x58, 0x00,
	'S','B','A',		0x81, 0x10, 0x00,
	'T','A','B',		0x81, 0x16, 0x00,
	'T','B','A',		0x81, 0x17, 0x00,
	'T','A','P',		0x81, 0x06, 0x00,
	'T','P','A',		0x81, 0x07, 0x00,
	'T','S','T','A',	0x81, 0x4d, 0x00,
	'T','S','T','B',	0x81, 0x5d, 0x00,
	'D','E','X',		0x81, 0x09, 0x00,
	'D','E','Y',		0x81, 0x09, 0x02,
	'D','E','S',		0x81, 0x34, 0x00,
	'I','N','X',		0x81, 0x08, 0x00,
	'I','N','Y',		0x81, 0x08, 0x02,
	'I','N','S',		0x81, 0x31, 0x00,
	'T','X','S',		0x81, 0x35, 0x00,
	'T','Y','S',		0x81, 0x35, 0x02,
	'T','S','X',		0x81, 0x30, 0x00,
	'T','S','Y',		0x81, 0x30, 0x02,
	'R','T','I',		0x81, 0x3b, 0x00,
	'R','T','S',		0x81, 0x39, 0x00,
	'S','W','I',		0x81, 0x3f, 0x00,
	'W','A','I',		0x81, 0x3e, 0x00,
	'A','B','X',		0x81, 0x3a, 0x00,
	'A','B','Y',		0x81, 0x3a, 0x02,
	'A','S','L','D',	0x81, 0x05, 0x00,
	'L','S','L','D',	0x81, 0x05, 0x00,
	'L','S','R','D',	0x81, 0x04, 0x00,
	'P','S','H','X',	0x81, 0x3c, 0x00,
	'P','S','H','Y',	0x81, 0x3c, 0x02,
	'P','U','L','X',	0x81, 0x38, 0x00,
	'P','U','L','Y',	0x81, 0x38, 0x02,
	'X','G','D','X',	0x81, 0x8f, 0x00,
	'X','G','D','Y',	0x81, 0x8f, 0x02,
	'M','U','L',		0x81, 0x3d, 0x00,
	'F','D','I','V',	0x81, 0x03, 0x00,
	'I','D','I','V',	0x81, 0x02, 0x00,
	'C','L','C',		0x81, 0x0c, 0x00,
	'C','L','V',		0x81, 0x0a, 0x00,
	'C','L','I',		0x81, 0x0e, 0x00,
	'S','E','C',		0x81, 0x0d, 0x00,
	'S','E','V',		0x81, 0x0b, 0x00,
	'S','E','I',		0x81, 0x0f, 0x00,
	'S','T','O','P',	0x81, 0xcf, 0x00,
	'T','E','S','T',	0x81, 0x00, 0x00,
	'N','O','P',		0x81, 0x01, 0x00,
	'A','D','D','A',	0x82, 0x8b, 0x00,
	'A','D','D','B',	0x82, 0xcb, 0x00,
	'A','D','C','A',	0x82, 0x89, 0x00,
	'A','D','C','B',	0x82, 0xc9, 0x00,
	'A','N','D','A',	0x82, 0x84, 0x00,
	'A','N','D','B',	0x82, 0xc4, 0x00,
	'B','I','T','A',	0x82, 0x85, 0x00,
	'B','I','T','B',	0x82, 0xc5, 0x00,
	'C','M','P','A',	0x82, 0x81, 0x00,
	'C','M','P','B',	0x82, 0xc1, 0x00,
	'E','O','R','A',	0x82, 0x88, 0x00,
	'E','O','R','B',	0x82, 0xc8, 0x00,
	'L','D','A','A',	0x82, 0x86, 0x00,
	'L','D','A','B',	0x82, 0xc6, 0x00,
	'O','R','A','A',	0x82, 0x8a, 0x00,
	'O','R','A','B',	0x82, 0xca, 0x00,
	'S','U','B','A',	0x82, 0x80, 0x00,
	'S','U','B','B',	0x82, 0xc0, 0x00,
	'S','B','C','A',	0x82, 0x82, 0x00,
	'S','B','C','B',	0x82, 0xc2, 0x00,
	'L','D','D',		0x83, 0xcc, 0x00,
	'A','D','D','D',	0x83, 0xc3, 0x00,
	'S','U','B','D',	0x83, 0x83, 0x00,
	'C','P','D',		0x83, 0x83, 0x08,	/* 'D' special */
	'C','P','X',		0x83, 0x8c, 0x01,
	'C','P','Y',		0x83, 0x8c, 0x04,	/* 'Y' special */
	'L','D','X',		0x83, 0xce, 0x01,
	'L','D','Y',		0x83, 0xce, 0x04,	/* 'Y' special */
	'L','D','S',		0x83, 0x8e, 0x00,
	'S','T','A','A',	0x84, 0x97, 0x00,
	'S','T','A','B',	0x84, 0xd7, 0x00,
	'S','T','X',		0x84, 0xdf, 0x01,
	'S','T','Y',		0x84, 0xdf, 0x04,	/* 'Y' special */
	'S','T','S',		0x84, 0x9f, 0x00,
	'S','T','D',		0x84, 0xdd, 0x00,
	'J','S','R',		0x84, 0x9d, 0x00,
	'C','L','R',		0x85, 0x6f, 0x00,
	'C','O','M',		0x85, 0x63, 0x00,
	'N','E','G',		0x85, 0x60, 0x00,
	'D','E','C',		0x85, 0x6a, 0x00,
	'I','N','C',		0x85, 0x6c, 0x00,
	'R','O','L',		0x85, 0x69, 0x00,
	'R','O','R',		0x85, 0x66, 0x00,
	'A','S','L',		0x85, 0x68, 0x00,
	'A','S','R',		0x85, 0x67, 0x00,
	'L','S','R',		0x85, 0x64, 0x00,
	'L','S','L',		0x85, 0x68, 0x00,
	'T','S','T',		0x85, 0x6d, 0x00,
	'J','M','P',		0x85, 0x6e, 0x00,
	'B','C','L','R',	0x86, 0x15, 0x00,
	'B','S','E','T',	0x86, 0x14, 0x00,
	'B','R','C','L','R',0x87, 0x13, 0x00,
	'B','R','S','E','T',0x87, 0x12, 0x00,
	'B','R','A',		0x88, 0x20, 0x00,
	'B','C','C',		0x88, 0x24, 0x00,
	'B','C','S',		0x88, 0x25, 0x00,
	'B','H','S',		0x88, 0x24, 0x00,
	'B','L','O',		0x88, 0x25, 0x00,
	'B','E','Q',		0x88, 0x27, 0x00,
	'B','G','E',		0x88, 0x2c, 0x00,
	'B','G','T',		0x88, 0x2e, 0x00,
	'B','H','I',		0x88, 0x22, 0x00,
	'B','L','E',		0x88, 0x2f, 0x00,
	'B','L','S',		0x88, 0x23, 0x00,
	'B','L','T',		0x88, 0x2d, 0x00,
	'B','M','I',		0x88, 0x2b, 0x00,
	'B','N','E',		0x88, 0x26, 0x00,
	'B','V','C',		0x88, 0x28, 0x00,
	'B','V','S',		0x88, 0x29, 0x00,
	'B','P','L',		0x88, 0x2a, 0x00,
	'B','S','R',		0x88, 0x8d, 0x00,
	'B','R','N',		0x88, 0x21, 0x00,
/* directives */
	'E','Q','U',		228,	0,	0,
	'O','R','G',		229,	0,	0,
	'F','C','B',		230,	0,	0,
	'F','D','B',		231,   -1,	0,
	'R','D','B',		231,	0,	0,
	'F','C','C',		232,	0,	0,
	'F','C','C','H',	232,	1,	0,
	'F','C','C','Z',	232,	2,	0,
	'R','M','B',		233,	0,	0,
	'D','B',			230,	0,	0,
	'D','W',			231,	-1,	0,
	'D','R','W',		231,	0,	0,
	'S','T','R',		232,	0,	0,
	'S','T','R','H',	232,	1,	0,
	'S','T','R','Z',	232,	2,	0,
	'D','S',			233,	0,	0,
	'E','N','D',		234,	0,	0,
	'P','A','G','E',	248,	0,	0,
	'T','I','T','L','E',249,	0,	0,
	'S','P','A','C','E',250,	0,	0,
	'L','I','S','T',	251,	0,	0,
	'N','O','L','I','S','T',252,0,	0,
	'L','I','N','E',	253,	0,	0,
	0 };	/* end of table */

/* addressing mode offset tables */
/* -------------- Imm.  Dir.  Ind.  Ext. */
char optab1[] = { 0x00, 0x10, 0x20, 0x30 };
char optab2[] = { 0xff, 0x00, 0x10, 0x20 };
char optab3[] = { 0xff, 0xff, 0x00, 0x10 };
char optab4[] = { 0xff, 0x00, 0x08, 0xff };
char optab5[] = { 0xff, 0x00, 0x0c, 0xff };

/*
 * Prebyte calculation table
 *	Bit:	0	- 'X' is involved
 *			1	- 'Y' is involved
 *			2-n	-	0 = No special
 *					1 = 'Y' special case
 *					2 = 'D' special case
 */
char pretab[] = {	0x00, 0x00, 0x18, 0xcd,
					0x18, 0x1a, 0x18, 0x1a,
					0x1a, 0x1a, 0xcd, 0xcd };

/* error messages */
static char *etext[] = { "?",
	"Unknown instruction",
	"Out of range",
	"Invalid addressing mode",
	"Invalid register specification",
	"Undefined symbol",
	"Invalid expression syntax",
	"Invalid argument format",
	"Improperly delimited string" } ;

/* Symbol table & free pointer */
char symtab[SYMB_POOL], *symtop;

/* misc. global variables */
char buffer[LINE_SIZE+1], label[SYMB_SIZE+1], title[50], operand[80], optr,
	itype, opcode, prebyte;
unsigned char instruction[80], outrec[35];

char optf=3, symf=0, intel=0, fulf=0, quietf=0, nlist=0, casf=0;

unsigned addr, line=0, pcount=0, lcount=0, value, length, emsg, ecnt,
	ocnt=0, pagel=59, pagew=80;

FILE *asm_fp, *hex_fp, *lst_fp;

/*
 * Define a symbol in the symbol table
 */
char *create_symbol(symbol, value)
	char *symbol;
	int value;
{
	register char *ptr, *ptr1;

	ptr = ptr1 = symtop;
	while(*symbol)
		*++ptr = *symbol++;
	*ptr1 = ptr - ptr1;
	*++ptr = value >> 8;
	*++ptr = value;
	if(ptr < (symtab+sizeof(symtab))) {
		symtop = ptr + 1;
		return ptr1; }
	return 0;
}

/*
 * Lookup a symbol in the symbol table
 */
char *lookup_symbol(symbol)
	char *symbol;
{
	register int l;
	register unsigned char *ptr, *ptr1;
	char *ptr2;

	ptr = symtab;
again:
	if((ptr2 = ptr) >= symtop) {
		value = 0x8888;
		return 0; }
	ptr1 = symbol;
	l = *ptr++ & SYMMASK;
	while(l--) {
		if(*ptr1++ != *ptr++) {
			ptr += l + 2;
			goto again; } }
	if(*ptr1) {
		ptr += 2;
		goto again; }
	value = *ptr++ << 8;
	value |= *ptr;
	return ptr2;
}

/*
 * Set the value for a symbol in the symbol table
 */
set_symbol(ptr, value)
	char *ptr;
	unsigned value;
{
	ptr += (*ptr & SYMMASK);
	*++ptr = value >> 8;
	*++ptr = value;
}

/*
 * Display the symbol table (sorted)
 */
dump_symbols()
{
	unsigned char *ptr, *hptr;
	unsigned int l, h, w;

	fprintf(lst_fp, "SYMBOL TABLE:\n\n");
	w = 0;
	for(;;) {
		for(hptr = symtab; hptr < symtop; hptr += (*hptr & SYMMASK) + 3)
			if(!(*hptr & SYMSORT))
				goto found;
		putc('\n', lst_fp);
		return;
found:	for(ptr = (*hptr & SYMMASK) + hptr + 3; ptr < symtop; ptr += (*ptr & SYMMASK) + 3) {
			if(*ptr & SYMSORT)
				continue;
			if(compsym(ptr, hptr) < 0)
				hptr = ptr; }
		*(ptr = hptr) |= SYMSORT;
		h = l = *ptr++ & SYMMASK;
		if((w + l + 7) >= pagew) {			/* Overrun page length */
			putc('\n', lst_fp);
			w = 0; }
		if(w) {								/* Not a start of line - separate */
			fprintf(lst_fp, "   ");
			w += 3; }
		while(l--)
			putc(*ptr++, lst_fp);
		w += (l = (h > 8) ? 24 : 8) + 5;	/* Calculate extended length */
		while(h++ < l)
			putc(' ', lst_fp);
		l = *ptr++ << 8;
		l |= *ptr++;
		fprintf(lst_fp, "-%04x", l); }
}

/*
 * Compare two symbol table entries
 */
compsym(sym1, sym2)
	char *sym1;
	char *sym2;
{
	int l, l1, l2;
	l1 = *sym1++ & SYMMASK;
	l2 = *sym2++ & SYMMASK;
	l = (l1 < l2) ? l1 : l2;
	do {
		if(*sym1 > *sym2)
			return 1;
		if(*sym1++ < *sym2++)
			return -1; }
	while(--l);
	if(l1 > l2)
		return 1;
	if(l1 < l2)
		return -1;
	return 0;
}

/************************************/
/* get a character from the operand */
/************************************/
char getchr()
{
	register char chr;

	if(chr=operand[optr]) ++optr;
	return(chupper(chr));
}

/*
 * Convert character to upper case if NOT case sensitive
 */
chupper(c)
	char c;
{
	return casf ? c : ((c >= 'a') && (c <= 'z')) ? c - ('a'-'A') : c;
}

/*
 * Open a filename with the appriopriate extension &
 * report an error if not possible
 */
FILE *open_file(filename, extension, options)
	char *filename, *extension, *options;
{
	char buffer[100], *ptr, *dot;
	FILE *fp;

	dot = 0;

	for(ptr = buffer; *ptr = *filename; ++ptr) {	/* Copy filename */
		if(*filename == '.')
			dot = filename;
		else if(*filename == '\\')
			dot = 0;
		++filename; }

	if(!dot) {									/* No extension supplied */
		*ptr++ = '.';
		do
			*ptr++ = *extension;
		while(*extension++); }
	else
		*dot = 0;

	if(!(fp = fopen(buffer, options))) {
		fprintf(stderr,"Unable to access: '%s'\n", buffer);
		exit(-1); }

	return fp;
}

/*
 * Main program
 */
main(argc, argv)
	unsigned argc;
	char *argv[];
{	unsigned i, temp, daddr, vbyt;
	int stemp;
	char chr, cflg, pflg, *ptr, *lfile, *cfile;

	if(argc < 2)
		abort("\nUse: asm11 <filename> [-cfiqst c=file l=file o=n p=length w=width]\n\n?COPY.TXT 1983-2005 Dave Dunfield\n**See COPY.TXT**.\n");

	pflg = 0;

/* parse for command line options. */
	lfile = cfile = argv[1];
	for(i=2; i < argc; ++i) {
		if(*(ptr = argv[i]) == '-') {		/* Enable switch */
			while(*++ptr) switch(toupper(*ptr)) {
				case 'C' : casf = -1;		break;
				case 'F' : fulf = -1;		break;
				case 'I' : intel = -1;		break;
				case 'Q' : quietf = -1;		break;
				case 'S' : symf = -1;		break;
				case 'T' : lfile = 0;		break;
				default: goto badopt; }
			continue; }
		if(*++ptr == '=') switch(toupper(*(ptr++ - 1))) {
			case 'L' : lfile = ptr;			continue;
			case 'C' : cfile = ptr;			continue;
			case 'O' : optf=atoi(ptr);		continue;
			case 'P' : pagel=atoi(ptr)-1;	continue;
			case 'W' : pagew=atoi(ptr);		continue; }
	badopt:
		fprintf(stderr,"Invalid option: %s\n", argv[i]);
		exit(-1); }

	asm_fp = open_file(argv[1], "ASM", "r");
	hex_fp = open_file(cfile, "HEX", "w");
	lst_fp = (lfile) ? open_file(lfile, "LST", "w") : stdout;
	strncpy(title,argv[1],sizeof(title)-1);

/* first pass - build symbol table */
	symtop = symtab;
	do {
		addr = cflg = 0; line = 1;
		if(!quietf)
			fprintf(stderr, pflg ? "Opt... " : "First pass... ");
		while(readline()) {
			if(!optr) {
				locins(instruction);
				if(label[0]) {				/* label exists */
					if(pflg) {				/* optomization pass */
						ptr = lookup_symbol(label);
						if(itype==100) {	/* EQU statement */
							optr = 0; vbyt = value;
							if((temp=eval()) != vbyt) {
								if(pflg >= optf) optfail();
								set_symbol(ptr, temp);
								cflg=1; } }
						else if(value != addr) {
							if(pflg >= optf) optfail();
							set_symbol(ptr, addr);
							cflg=1; } }
					else {							/* original pass-1 */
						if(lookup_symbol(label)) {	/* duplicate label */
							fprintf(lst_fp,"** Line %u - Duplicate symbol: '%s'\n",line,label);
							++ecnt; }
						else {
							cflg=1;			/* indicate symbol table change */
							if(!(ptr = create_symbol(label, addr))) {
								xabort("symbol");
								fprintf(lst_fp,"** Line %u - Symbol table overflow\n", line);
								++ecnt;
								break; } } } }
				emsg = length = optr = 0;
				switch(itype) {
					case 1 :		/* inherent addressing */
						++length;
						break;
					case 2 :		/* full memory reference */
						memop(optab1);
						break;
					case 3 :		/* full, 3 byte immed */
						memop(optab1);
						if(!itype)
							++length;
						break;
					case 4 :		/* dir, indexed, and extended only */
						memop(optab2);
						break;
					case 5 :		/* indexed and extended only */
						memop(optab3);
						break;
					case 6 :		/* bit set and clear */
						memop(optab4);
						++length;
						break;
					case 7 :		/* bit branches */
						memop(optab5);
						length += 2;
						break;
					case 8 :		/* branches */
						length = 2;
						break;
					case 100 :			/* EQU directive */
						if(!pflg) {
							set_symbol(ptr, eval());
						err1st:
							if(emsg && !optf) {
								fprintf(lst_fp,"** Line %u - %s\n",line,etext[emsg]);
								++ecnt; } }
						break;
					case 101 :			/* ORG directive */
						addr=eval();
						goto err1st;
					case 102 :			/* FCB statement */
						length=1;
						while(nxtelem()) ++length;
						break;
					case 103 :			/* FDB statement */
						length=2;
						while(nxtelem()) length += 2;
						break;
					case 104 :			/* FCC statements */
						chr=operand[0];
						for(i=1;(operand[i])&&(chr!=operand[i]); ++i) ++length;
						if(opcode == 2) ++length;
						break;
					case 105 :			/* RMB statement */
						addr = addr + eval();
						goto err1st;
					case 106 :			/* END statement */
						goto end1;
					case 125 :			/* LINE statement */
						line = eval(); }
				if(pretab[prebyte])		/* Include prefix byte */
					++length; }
			else
				length = 0;
			addr += length;
			++line; /* += (itype < 120); */ }
end1:	++pflg;
		rewind(asm_fp); }
	while((optf)&&(cflg)&&(!ecnt));

/* second pass - generate object code */

	if(!quietf)
		fprintf(stderr,"Second pass... ");
	addr = emsg = 0; line = pcount = 1; lcount = 9999;
	while(readline()) {
		daddr = addr;
		if(!optr) {
			if(!locins(instruction))
				reperr(1);			/* unknown opcode */
			length = temp = optr = 0;
			switch(itype) {
				case 1 :		/* inherent addressing */
					itype = 0;
					goto wrinst;
				case 2 :		/* full memory reference */
					memop(optab1);
					goto wrinst;
				case 3 :		/* full, three byte immediate */
					memop(optab1);
					if(!itype)
						++length;
					goto wrinst;
				case 4 :		/* dir, indexed, and extended only */
					memop(optab2);
					goto wrinst;
				case 5 :		/* indexed and extended only */
					memop(optab3);
wrinst:				if(pretab[prebyte])		/* 'Y' index operation */
						instruction[temp++] = pretab[prebyte];
					instruction[temp++] = opcode + itype;
					if(length > 2)
						instruction[temp++] = value >> 8;
					if(length > 1)
						instruction[temp++] = value & 255;
					length = temp;
					break;
				case 6 :			/* Bit set & clear */
					memop(optab4);
					if(!isterm(operand[optr-1]))
						reperr(7);
					length = 0;
					if(pretab[prebyte])
						instruction[length++] = pretab[prebyte];
					instruction[length++] = opcode + itype;
					instruction[length++] = value;
					instruction[length++] = eval();
					break;
				case 7 :			/* Bit conditional branches */
					memop(optab5);
					if(!isterm(operand[optr-1]))
						reperr(7);
					length = 0;
					if(pretab[prebyte])
						instruction[length++] = pretab[prebyte];
					instruction[length++] = opcode + itype;
					instruction[length++] = value;
					if(!isterm(operand[optr-1]))
						reperr(7);
					opcode = eval();
				case 8 :			/* branches */
					instruction[length++] = opcode;
					stemp = (eval() - addr) - (length+1);
					if((stemp > 127) || (stemp < -128))
						reperr(2);				/* out of range */
					instruction[length++] = stemp;
					break;
				case 100 :			/* equate statement */
					daddr=eval();	/* generate errors if any */
					break;
				case 101 :			/* ORG statement */
					if(ocnt) wrrec();
					daddr=addr=eval();
					break;
				case 102 :			/* FCB statement */
					do {
						instruction[length++] = eval(); }
					while(operand[optr-1] == ',');
					break;
				case 103 :			/* FDB statement */
					do {
						temp = eval();
						if(opcode) {
							instruction[length++] = temp >> 8;
							instruction[length++] = temp; }
						else {
							instruction[length++] = temp;
							instruction[length++] = temp >> 8; } }
					while(operand[optr-1] == ',');
					break;
				case 104 :			/* FCC statements */
					chr=operand[0];
					for(i=1;((operand[i])&&(chr!=operand[i])); ++i)
						instruction[length++] = operand[i];
					if(!operand[i])	reperr(8);
					if(opcode == 1)
						instruction[length-1] = instruction[length-1] | 0x80;
					if(opcode == 2)
						instruction[length++]=0;
					break;
				case 105 :			/* RMB statement */
					if(ocnt) wrrec();
					addr += eval();
					break;
				case 106 :			/* END statement */
					goto end2;
				case 120 :			/* PAGE statement */
					lcount=9999;
					break;
				case 121 :			/* TITLE directive */
					strncpy(title, operand, sizeof(title)-1);
					break;
				case 122 :			/* SPACE directive */
					fprintf(lst_fp,"\n");
					++lcount;
					break;
				case 123 :			/* LIST directive */
					if(nlist) --nlist;
					break;
				case 124 :			/* NOLIST directive */
					++nlist;
					break;
				case 125 :			/* LINE directive */
					line = eval(); } }
		else
			length=itype=0;

/* generate listing */
	if(((itype<120) && fulf && !nlist) || emsg) {
		if(++lcount >= pagel)
			write_title();
		fprintf(lst_fp,"%04x ",daddr);
			for(i=0; i < 6; ++i) {
				if(i < length)
					fprintf(lst_fp," %02x",instruction[i]);
				else
					fprintf(lst_fp,"   "); }
			fprintf(lst_fp," %c%5u  %s\n",(length <= 6) ? ' ' : '+',line,buffer); }
		if(emsg) {
			fprintf(lst_fp,"  ** ERROR ** - %u - %s\n", emsg, etext[emsg]);
			++ecnt; ++lcount;
			emsg=0; }
		++line; /* += (itype<120); */
/* write code to output record */
	for(i=0; i<length; ++i) {
		if(!ocnt) {			/* first byte of record */
			outrec[ocnt++]=addr>>8;
			outrec[ocnt++]=addr; }
		++addr;
		outrec[ocnt++]=instruction[i];
		if(ocnt>33) wrrec(); } }	/* record is full, write it */

end2:
	if(ocnt) wrrec();
	if(intel) fprintf(hex_fp,":00000001FF\n");
	else fprintf(hex_fp,"S9030000FC\n");

	if(ecnt) fprintf(lst_fp,"\n %u error(s) occurred in this assembly.\n",ecnt);
	if(!quietf) fprintf(stderr,"%u error(s).\n",ecnt);

/* display the symbol table */
	if(symf) {
		write_title();
		dump_symbols(); }

	fclose(asm_fp);
	fclose(hex_fp);
	fclose(lst_fp);

	return ecnt ? -2 : 0;
}

/***********************************************/
/* lookup instruction in the instruction table */
/***********************************************/
int locins(inst)
	char inst[];
{
	register char *ptr, *ptr1;

	ptr = opcodes;
	do {
		ptr1 = inst;
		while(*ptr == *ptr1) {
			++ptr;
			++ptr1; }
		if((*ptr < 0) && !*ptr1) {
			itype = *ptr++ & 127;
			opcode = *ptr++;
			prebyte = *ptr++;
			return 1; }
		while(*ptr > 0)
			++ptr; }
	while(*(ptr += 3));

	itype = 119;
	return(inst[prebyte = 0] == 0);
}

/*************************************************/
/* read a line from input file, and break it up. */
/*************************************************/
int readline()
{
	register int i;
	register char *ptr;

	if(!fgets(ptr = buffer, LINE_SIZE, asm_fp))
		return 0;

	i = 0;
	while(issymbol(*ptr)) {
		label[i] = chupper(*ptr++);
		if(i < SYMB_SIZE)
			++i; }
	label[i]=0;
	if(*ptr == ':')
		++ptr;
	while(isspace(*ptr))
		++ptr;
	if(((*ptr != '*') && (*ptr != ';')) || i) {
		i = 0;
		while(*ptr && !isspace(*ptr))
			instruction[i++] = toupper(*ptr++);
		instruction[i]=0;
		while(isspace(*ptr))
			++ptr;
		optr = i = 0;
		while(*ptr && (i < 79))
			operand[i++] = *ptr++;
		operand[i] = 0;
		return 1; }

	return optr = 1;
}

/***************************************/
/* test for valid terminator character */
/***************************************/
int isterm(chr)
	register char chr;
{
	switch(chr) {
		case 0 :
		case ' ' :
		case '\t':
		case ',' :
		case ';' :
		case ')' :
			return 1; }
	return 0;
}

/*************************************/
/* Test for a valid symbol character */
/*************************************/
int issymbol(c)
	char c;
{
	switch(c) {			/* Special allowed characters */
		case '_' :
		case '?' :
		case '!' :
		case '.' :
			return 1; }

	return isalnum(c);
}

/* report an error */
reperr(errn)
	register int errn;
{	if(!emsg) emsg=errn;
}

/*******************************/
/* write record to output file */
/*******************************/
wrrec()
{	register unsigned i, chk, chr;

	xhex(ocnt-2);
	if(intel) {					/* intel hex format */
		chk = outrec[0] + outrec[1] + ocnt - 2;
		fprintf(hex_fp,":%02x%02x%02x00", ocnt-2, outrec[0], outrec[1]);
		for(i=2; i<ocnt; ++i) {
			fprintf(hex_fp,"%02x", chr = outrec[i]);
			chk += chr; }
		fprintf(hex_fp,"%02x\n", 255 & (0-chk)); }
	else {						/* motorola hex format */
		chk = ocnt + 1;
		fprintf(hex_fp,"S1%02x", ocnt + 1);
		for(i=0; i<ocnt; ++i) {
			fprintf(hex_fp,"%02x", chr = outrec[i]);
			chk += chr; }
		fprintf(hex_fp,"%02x\n", 255 & ~chk); }
	ocnt = 0;
}

/*
 * Evaluate an expression.
 */
int eval()
{	register char c;
	unsigned result;

	result=getval();
	while(!isterm(c = getchr())) switch(c) {
		case '+' : result += getval();	break;
		case '-' : result -= getval();	break;
		case '*' : result *= getval();	break;
		case '/' : result /= getval();	break;
		case '\\': result %= getval();	break;
		case '&' : result &= getval();	break;
		case '|' : result |= getval();	break;
		case '^' : result ^= getval();	break;
		case '<' : result <<= getval();	break;
		case '>' : result >>= getval();	break;
		default: reperr(6); }

	return result;
}

/*
 * Get a single value (number or symbol)
 */
int getval()
{
	unsigned i, b, val;
	char chr, array[25], *ptr;

	switch(chr = operand[optr++]) {
		case '-' :				/* Negated value */
			return 0 - getval();
		case '~' :				/* Complemented value */
			return ~getval();
		case '=' :				/* Swap high and low bytes */
			i=getval();
			return (i<<8)+(i>>8);
		case '(' :				/* Nested expression */
			val = eval();
			if(operand[optr-1] != ')')
				reperr(6);
			return val; }
	--optr;

	val=b=i=0;
	switch(chr) {
		case '$' :	b = 16;	goto getnum;
		case '@' :	b = 8;	goto getnum;
		case '%' :	b = 2;	goto getnum; }
	if(isdigit(chr)) {
		array[i++] = chr;
	getnum:
		while(isalnum(chr = toupper(operand[++optr])))
			array[i++] = (chr < 'A') ? chr : chr - 7;
		if((b == 16) && !i)
			val = addr;
		else {
			if(!b) {
				b = 10;
				switch(array[i-1]) {
					case 'H'-7 :	b = 16;	goto deci;
					case 'T'-7 :
					case 'D'-7 :	b = 10;	goto deci;
					case 'Q'-7 :
					case 'O'-7 :	b = 8;	goto deci;
					case 'B'-7 :	b = 2;
					deci:	--i;	} }
			if(!i)
				reperr(6);
			for(ptr = array; i; --i) {
				if((chr = *ptr++ - '0') >= b)
					reperr(6);
				val = (val * b) + chr; } } }
	else if(chr=='\'') {				/* Single quote. */
		++optr;
		while(((chr=operand[optr++]) != '\'')&& chr)
			val=(val << 8)+chr;
		if(!chr) reperr(8); }
	else if(chr=='*') {					/* Program counter */
		++optr;
		val=addr; }
	else {								/* Must be a label */
		i = 0;
		while(issymbol(chr = chupper(operand[optr]))) {
			++optr;
			label[i]=chr;
			if(i < SYMB_SIZE)
				++i; }
		label[i]=0;

		if(!lookup_symbol(label)) reperr(5);
		val=value; }

	return val;
}

/* evaluate memory operand, and determine type of */
/* addressing, and size of instruction.           */
int memop(optab)
	char optab[];
{
	register char chr;

	value = optr = length = 0;
	if((chr = chupper(operand[optr++])) == '#' ) {	/* immediate addressing */
		value = eval();
		itype = optab[0];
		length = 2; }
	else if(chr == '>') {			/* extended reference */
		value = eval();
		itype = optab[3];
		length = 3; }
	else if(chr == '<') {			/* zero page addressing */
		value = eval();
		itype = optab[1];
		length = 2; }
	else if(chr == ',') {
		if((chr = chupper(operand[optr++])) == 'X')
			prebyte |= 0x01;
		else if(chr == 'Y')
			prebyte |= 0x02;
		else
			reperr(4);
		itype = optab[2];
		length = 2;
		++optr; }
	else {						/* not simple case */
		--optr;
		value = eval();					/* get value for offset */
		if(operand[optr-1] == ',') {	/* indexed */
			if((chr = chupper(operand[optr++])) == 'X')
				prebyte |= 0x01;
			else if(chr == 'Y')
				prebyte |= 0x02;
			else
				reperr(4);
			itype = optab[2];
			length = 2;
			++optr; }
		else {		/* extended or direct addressing */
			if(optab[3] == -1) {	/* Zero page only */
				if(value > 255)
					reperr(3);
				itype = optab[1];
				length = 2; }
			else if(optf && (value < 256) && (optab[1] != -1)) {	/* Zero page */
				itype = optab[1];
				length = 2; }
			else {					/* extended */
				itype = optab[3];
				length = 3; } } }
	if(itype == -1)
		reperr(3);
}

/*
 * Write out title
 */
write_title()
{
	int w;
	char *ptr;

	if(pcount > 1)
		putc('\f',lst_fp);
	lcount = 1;
	fprintf(lst_fp,"DUNFIELD 6811 ASSEMBLER: ");
	ptr = title;
	for(w = 35; w < pagew; ++w)
		putc(*ptr ? *ptr++ : ' ', lst_fp);
	fprintf(lst_fp,"PAGE: %u\n\n", pcount);
	++pcount;
}

/**************************************/
/* find next element in argument list */
/**************************************/
int	nxtelem() {
	register char chr;
	while((chr=operand[optr])&&(chr != ' ')&&(chr != 9)) {
		++optr;
		if(chr==39) {
			while((chr=operand[optr])&&(chr!=39)) ++optr;
			++optr; }
		if(chr==',') return(1); }
	return(0);
}

/*
 * Too many optimization passes - report failure
 */
optfail()
{
	fprintf(lst_fp,"** Line %u - Unable to resolve: %s\n", line, label);
	++ecnt;
}
